# Discord-Token-Stealer
![alt text](https://i.imgur.com/YWEBcLX.png)


### If you open the program then it's sending a message through a discord webhook with the following informations:
#### - Computer UserName
#### - OS
#### - Token from the discord app
#### - Token from google chrome

### VS Version used:
#### - Visual Studio 2019 Community

# Disclaimer
## I, the creator, am in no way responsible for any actions that you may make using this software. You take full responsibility with any action taken using this software. Please take note that this application was designed for educational purposes and should never be used maliciously. By downloading the software or source to the software, you automatically accept this agreement.
